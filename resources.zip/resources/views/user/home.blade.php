@extends('user.layout.app')
@section('title')Home @endsection
@section('contents')

home
@endsection